/*
 * Copyright(c) 2014-2015 NTT Corporation.
 */
/**
 * 会員情報機能共通のアプリケーション層パッケージ。
 * 
 * @author NTT 電電花子
 */
package jp.co.ntt.atrs.app.c0;