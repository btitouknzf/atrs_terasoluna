/*
 * Copyright(c) 2014-2015 NTT Corporation.
 */
/**
 * チケット予約共通のアプリケーション層パッケージ。
 * 
 * @author NTT 電電次郎
 */
package jp.co.ntt.atrs.app.b0;