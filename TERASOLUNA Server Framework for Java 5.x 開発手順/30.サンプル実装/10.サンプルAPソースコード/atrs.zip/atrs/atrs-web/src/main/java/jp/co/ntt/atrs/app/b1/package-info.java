/*
 * Copyright(c) 2014-2015 NTT Corporation.
 */
/**
 * 空席照会アプリケーション層パッケージ。
 * 
 * @author NTT 電電太郎
 */
package jp.co.ntt.atrs.app.b1;