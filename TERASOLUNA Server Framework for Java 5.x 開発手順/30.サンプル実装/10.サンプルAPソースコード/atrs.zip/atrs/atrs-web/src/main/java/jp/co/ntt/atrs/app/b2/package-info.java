/*
 * Copyright(c) 2014-2015 NTT Corporation.
 */
/**
 * チケット予約アプリケーション層パッケージ。
 * 
 * @author NTT 電電三郎
 */
package jp.co.ntt.atrs.app.b2;