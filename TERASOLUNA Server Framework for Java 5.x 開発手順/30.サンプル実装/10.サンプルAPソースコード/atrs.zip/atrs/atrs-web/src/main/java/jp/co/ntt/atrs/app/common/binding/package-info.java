/*
 * Copyright(c) 2014-2015 NTT Corporation.
 */
/**
 * バインディング設定用パッケージ。
 * 
 * @author 電電太郎
 */
package jp.co.ntt.atrs.app.common.binding;