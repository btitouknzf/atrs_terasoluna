/*
 * Copyright(c) 2014-2015 NTT Corporation.
 */
/**
 * 業務共通のパッケージ。
 * 
 * @author NTT 電電太郎
 */
package jp.co.ntt.atrs.domain.service.a0;