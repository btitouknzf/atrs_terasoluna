/*
 * Copyright(c) 2014-2015 NTT Corporation.
 */
/**
 * マスターデータ管理に関するパッケージ。
 * 
 * @author NTT 電電太郎
 */
package jp.co.ntt.atrs.domain.common.masterdata;