/*
 * Copyright(c) 2014-2015 NTT Corporation.
 */
/**
 * 運賃種別のリポジトリパッケージ。
 * 
 * @author NTT 電電太郎
 */
package jp.co.ntt.atrs.domain.repository.faretype;