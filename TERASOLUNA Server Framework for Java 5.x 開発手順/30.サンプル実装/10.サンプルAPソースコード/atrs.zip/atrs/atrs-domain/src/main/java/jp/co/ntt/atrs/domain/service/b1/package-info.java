/*
 * Copyright(c) 2014-2015 NTT Corporation.
 */
/**
 * 空席照会サービスパッケージ。
 * 
 * @author NTT 電電次郎
 */
package jp.co.ntt.atrs.domain.service.b1;