/*
 * Copyright(c) 2014-2015 NTT Corporation.
 */
/**
 * チケット予約共通サービスパッケージ
 * 
 * @author NTT 電電太郎
 */
package jp.co.ntt.atrs.domain.service.b0;