/*
 * Copyright(c) 2014-2015 NTT Corporation.
 */
/**
 * 会員情報変更サービスパッケージ。
 * 
 * @author NTT 電電花子
 */
package jp.co.ntt.atrs.domain.service.c2;