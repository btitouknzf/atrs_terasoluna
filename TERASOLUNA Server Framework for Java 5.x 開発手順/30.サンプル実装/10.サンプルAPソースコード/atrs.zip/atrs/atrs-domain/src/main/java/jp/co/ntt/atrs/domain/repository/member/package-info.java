/*
 * Copyright(c) 2014-2015 NTT Corporation.
 */
/**
 * 会員情報のリポジトリパッケージ。
 * 
 * @author NTT 電電太郎
 */
package jp.co.ntt.atrs.domain.repository.member;